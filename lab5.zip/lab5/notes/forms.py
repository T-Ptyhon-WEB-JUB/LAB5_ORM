from django import forms
from .models import notesT
class notesForm(forms.ModelForm):
    class Meta:
        model = notesT
        fields = '__all__' #to include all fields