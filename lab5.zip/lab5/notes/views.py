from django.shortcuts import render, redirect, resolve_url
from django.http import HttpResponse, HttpRequest
from .forms import notesForm
from .models import notesT

# from .forms import notes

# Create your view
# Create your views here.

def home(request):
    return render(request, 'base/base.html')

def index(request):
    notes = notesT.objects.all()
    return render(request, 'base/index.html', {"notes": notes})

def about(request):
    return render(request, 'base/about.html')

def adding(request):
    if request.method == 'POST':
        r = notesForm(request.POST)
        if r.is_valid():
            r.save()
            return redirect(resolve_url("notes:index"))
    form = notesForm()
    return render(request, 'base/adding.html', {"form": form})