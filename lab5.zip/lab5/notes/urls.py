from importlib.resources import path
from django.urls import path
from . import views

app_name = "notes"

urlpatterns = [
    path("", views.home, name = "home"),
    path("about/", views.about, name= "about"),
    path("index/", views.index, name= "index"),
    path("adding/", views.adding, name = 'adding'),

]